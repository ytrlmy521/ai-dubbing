
# --- 《熊出没小小世界》提示词模板 ---
XiongChuMo_XiaoXiao_ShiJie_PROMPT_TEMPLATE = """
翻译要求：将电影《熊出没小小世界》中文剧本译为法国法语配音稿。需确保：
1）角色身份准确，与第10项的任务身份一致（林双-前顶尖高材生/全职主妇，顾许-海归精英/林双同学，江喜-职场女性/林双闺蜜）,中文中涉及特殊术语的请参考第11项的翻译术语字典表，例如： 英文 "BRIAR"	 你直接使用术语对照表的结果就行：Bernard，"BRAMBLE" 直接使用 Benoît。
2）译文行数与原文逐行对应 
3）口语化表达符合角色身份 
4）专业术语保持语境一致 
5）保留1%行数弹性空间 
6）使用当代法国法语表达习惯 
7）确保口型同步适配 ，开闭口保持一致，语气使用活泼有趣的方式。
8）PG级语言规范。注意人物关系表述的自然流畅
9) 剧情背景介绍：The story is about a tour guide whose career is repeatedly unsuccessful, Vick, by chance, retrieved in the lost shrunken flashlight. In order to attract tourists, he has the bright idea of building a microscopic paradise. However, during a storm, the shrinking flashlight is accidentally lost, and Bald Head Strong and Bear Big and Bear Two are forced to shrink and embark on an adventurous journey to find the flashlight. They move between the “Night City” of the insect world and the human town, during which they start a battle of wits and courage, and finally help the insect world residents to solve the crisis.


10) 人物身份：
熊大，是动画片《熊出没》系列中的一头狗熊，也是《熊出没》系列中的男主角之一。是熊兄弟的主心骨，懂得坚持主见的重要性。是一头聪颖、智慧无边、有勇有谋的狗熊。 熊二，是动画片《熊出没》系列中的一头狗熊，也是《熊出没》系列中的男主角之一。他和哥哥熊大一起保护森林。他是一头憨厚、可爱、搞笑、聪颖、力大无穷、比较聪明的熊，也是森林的丛林守护者。 光头强，是动画片《熊出没》系列中的男主角之一。他是一个导游，是一个多方面的天才，而且勇气十足。跟熊大和熊二一起保护森林。


11)翻译术语字典表（英语	--> 法语)

CHARACTER NAME	FRENCH NAME
Boonie Bears：Shrunk	Les Ours Boonie：Shrunk
BRIAR	Bernard
BRAMBLE	Benoît
VICK	Charly
Seymore	Seymore
Sandy	Sandy
Kitty	Kitty
Howard Bold	Howard Bold
Tricky Boo	Tricky Boo
Shadow Shell	Shadow Shell
Pipesburg	Pipesburg
Sherman Stink	Sherman Stink



请严格按照上述要求，只将下面这一行英文文本翻译成法国法语，并直接返回翻译结果，仅返回译文，不要添加任何额外的解释或说明：
{text_to_translate}
"""


# --- DECEIT提示词模板 ---
DECEIT_PROMPT_TEMPLATE = """
翻译要求：将电视剧《DECEIT》中文剧本译为法国法语配音稿。需确保：

[Paramètres généraux]
Langue source: Anglais (EN)
Langue cible: Français de France (FR-FR)
Style: Dialogue de série TV
Niveau PG: 13+
Conservation noms propres: OUI
Forme: Registre informel (familier mais non vulgaire)
Intensité émotionnelle: Élevée (tensions dramatiques)
Alignement temporel: 100% synchronisé
Contraintes techniques:
* Nombre de lignes = source
* Écart syllabique ≤0% 
* Ponctuation expressive (!, ?, ...)

[Contexte narratif]
Genre: Mélodrame familial intense
Thèmes clés: 
- Adultère destructeur 
- Violence conjugale 
- Lutte de pouvoir fraternelle
- Enquête policière
Ambiance: Climat de suspicion permanente avec crescendo tragique

[Personnages & Profils linguistiques]
► Victor (boxeur) :
- Registre : Argot urbain + phrases hachées
- Tics verbaux : "Putain..." en incise, impératifs aggressifs
- Ex: "T'as cru pouvoir me tromper?!" 

► Juliana (épouse adultère) :
- Registre : Français courant avec ruptures émotionnelles
- Marqueurs de stress : Répétitions, ellipses
- Ex: "Je... je ne pouvais plus respirer... Alex m'a..."

► Alex (avocat déchu) :
- Registre : Registre soutenu dégradé (traces de langage juridique)
- Contrastes : Alternance sarcasme/rage
- Ex: "Vous croyez que le Code pénal m'impressionne maintenant?"

► Sylvia (épouse trahie) :
- Registre : Français standard teinté d'ironie amère
- Constructions : Questions rhétoriques
- Ex: "Et moi dans cette comédie, je joue quel rôle?"

[Instructions spéciales]
1. Conserver les métaphores corporelles (boxe = violence contenue)
2. Renforcer les oxymores relationnels : "frère ennemi", "amour interdit"
3. Garder les interjections typiques : "Aïe!" → "Aïe!", "Tsk" → "Tss"
4. Adapter les références juridiques avec équivalents français (ex : "disbarred" → "radiée du barreau")
5. Utiliser le tutoiement/vouvoiement stratégique pour refléter les rapports de pouvoir

[Contrôles qualité]
- Vérifier la progression des pronoms ("vous" → "tu" lors des confrontations)
- Maintenir le rythme haletant via des phrases nominales
- Garantir la fluidité des répliques cinglantes type :
"Tu voulais mon frère? Prends-le! Dans une boîte en pin!" 

Ce template permettra de restituer l'intensité dramatique tout en respectant les contraintes techniques de localisation. Souhaitez-vous des ajustements spécifiques ?	

请严格按照上述要求，只将下面这一行英文文本翻译成法国法语，并直接返回翻译结果，仅返回译文，不要添加任何额外的解释或说明：
{text_to_translate}
"""


# --- 《熊出没怪兽计划S2》提示词模板 ---
XiongChuMoGuai_JiaHua_PROMPT_TEMPLATE = """

翻译要求电影《熊出没怪兽计划S2》

**PROMPT DE TRADUCTION IA POUR FILM D'ANIMATION**  
*(avec synchronisation labiale)*  
-----------------------------------------------

**PARAMÈTRES FONDAMENTAUX**  
```  
Source: Anglais (script original)  
Cible: Français de France (FR-FR)  
Public: Enfants 6-12 ans (PG)  
Style: Dialogues dynamiques pour animation  
Émotion: Drôle + Aventure palpitante  
Contraintes techniques:  
✓ Lignes = 100% alignement source  
✓ Écart syllabique ≤1%  
✓ Rythme bouche synchronisée  
✓ Conservation noms propres: OUI (cf. tableau termes)  
```

**PERSONNAGES & PROFILS LINGUISTIQUES**  
▸ **Jean Trouve-tout (REX VECTOR)**  
- Registre : *Scientifique mégalo*  
- Tics verbaux : "Évidemment!", "Selon mes calculs..."  
- Ex: "Cette pierre énergétique *révolutionnera* la science!"  

▸ **Monsieur Pierre (MR. PETE)**  
- Registre : *Hamster malicieux*  
- Marqueurs : Interjections comiques ("Oh là là!"), voix aiguë  
- Ex: "*Ronger* des noix > sauver la forêt!"  

▸ **Bernard (BRIAR)** & **Benoît (BRAMBLE)**  
- Registre : *Frères ours complices*  
- Bernard : Sagesse enfantine ("Réfléchis avec ton cœur!")  
- Benoît : Naïveté comique ("Mais... les cristaux c'est comestible?")  

▸ **Charly (VICK)**  
- Registre : *Guide aventureux*  
- Spécificité : Métaphores culinaires ("Cette livraison, c'est la cerise sur le gâteau!")  

**STRATÉGIES DE LOCALISATION**  
1. **Jeux de mots adaptés**  
   Ex: "Delivery man" → "Livreur de délices" (rythme 7 syllabes)  

2. **Onomatopées cartoon**  
   - "Crash!" → "Badaboum!"  
   - "Zap!" → "Ziiiip!"  

3. **Rythme musical**  
   Utiliser des rimes internes pour les répliques clés :  
   *"Pas de cristal, pas de monstre, pas de gloire... Mais avec Pierre, c'est une autre histoire!"*  

**TABLEAU DE CONVERSION DYNAMIQUE**  
| Élément source | Adaptation FR | Notes |  
|----------------|---------------|-------|  
| Energy stone | Pierre Cosmique | Maintient le PG |  
| Unemployment crisis | Tempête de galère | Registre enfantin |  
| Invincible monster | Titan Imbattable | 7 syllabes |  

**CONTROLES QUALITÉ**  
- Vérifier les allitérations pour fluidité :  
  *"Vite, Vick! Vers la victoire!"*  
- Adapter les blagues visuelles :  
  Scène du licenciement → Ajouter un gag avec une tarte à la crème  

**EXEMPLE DE TRADUCTION CIBLÉE**  
*Source EN:*  
"Hey! My walnut stash! MR. PETE, you fluffy traitor!"  

*Adaptation FR:*  
"Hé ! Mon stock de noix ! Monsieur Pierre, espèce de boule de poils *trafiquée* !"  
*(12 syllabes vs 13 originales - écart 0.8%)*  


请严格按照上述要求，只将下面这一行英文文本翻译成法国法语，并直接返回翻译结果，仅返回译文，不要添加任何额外的解释或说明：
{text_to_translate}
"""





# --- 《《Danny and Mick》》提示词模板 ---
Danny_and_Mick_PROMPT_TEMPLATE = """
Style: Sitcom déjanté  
Registre: Familier (niveau "café du quartier")  
Rythme: Ping-pong verbal accéléré  
Contraintes techniques:  
✓ 100% synchronisation labiale  
✓ Écart syllabique = 0%  
✓ Conservation structure comique:  
   - Setup → Chute  
   - Triples répétitions  
   - Antithèses absurdes  

**PROFIL DES PERSONNAGES**  

▸ **Danny (homme-orchestre)**  
- Syntaxe: Phrases interrompues par des actions  
- Tics verbaux:  
  - "En théorie..." → *bruit de chute*  
  - "C'est sous contrôle!" → *catastrophe en cours*  
- Ex: "J'ai tout prévu! *[claquettes qui tombent]*... Enfin presque"  

▸ **Mick (vigile maladroit)**  
- Registre: Faux dur avec voix de fausset  
- Marqueurs:  
  - Métaphores martiales ratées  
  - Onomatopées exagérées ("PAN-pan-paaan!")  
- Ex: "Alarme activée! *[son de télévision]* Euh... fausse alerte?"  

▸ **Joy (patronne exaspérée)**  
- Structure: Questions rhétoriques en crescendo  
- Ponctuation: !!! stratégiques  
- Ex: "Vous appelez ÇA nettoyer?! *[montre un rouleau de PQ en feu]*"  

**STRATÉGIES D'HUMOUR**  
1. **Adaptation des calembours**  
   "Pool attendant" → "Maître-nageur... terrestre!" (même rythme)  

2. **Conservation du chaos**  
   - Ajouter des interjections physiques : "CLAC!" / "SPLOUCH!"  
   - Amplifier les contrastes tonals  

3. **Jeux de pronoms**  
   Utilisation intensive du "tu" pour :  
   - Créer des quiproquos ("Tu l'as fait?" "Non, c'est TOI!")  
   - Renforcer la complicité fraternelle  

**MATRICE D'INTERACTIONS**  
| Situation source | Élément clé | Adaptation FR |  
|------------------|-------------|---------------|  
| Slapstick water gag | Timing comique | Ajouter "GLOUP-GLOUP" synchronisé |  
| Magic trick fail | Suspens raté | "Abracada... brûle!" (7 syllabes) |  
| Boss confrontation | Exagération | "C'est la APOCALYPSE du ménage!!" |  

**EXEMPLE DE SCÈNE CIBLÉE**  
*Source EN:*  
Danny: "I've locked the fire exit!"  
Mick: "But... that's MY job!"  
*[alarm sounds]*  

*Adaptation FR:*  
Danny: "Sortie de secours verrouillée !"  
Mick: "Hé ! C'est MON boulot ça !"  
*[déclencheur d'arrosage automatique]*  

**CONTROLES QUALITÉ**  
- Vérifier le "rythme Buster Keaton" pour les gags visuels  
- Maintenir le débit verbal à 160 mots/minute  
- Garantir 3 fous rires par page de script  

请严格按照上述要求，只将下面这一行英文文本翻译成法国法语，并直接返回翻译结果，不要添加任何额外的解释或说明：
{text_to_translate}
"""



# --- 《天才小鲁班》提示词模板 ---
TianCaiXiaoLuBan_PROMPT_TEMPLATE = """

以下是为动画剧集《天才小鲁班》定制的法语本地化模板，融入工匠文化元素并适配青少年观众：

**PROMPT DE TRADUCTION IA POUR SÉRIE ÉDUCATIVE**  
*(avec conservation des termes d'artisanat)*  
--------------------------------------------------

**PARAMÈTRES FONDAMENTAUX**  
```  
Style: Aventure pédagogique  
Tonalité: Enthousiaste avec pointe de rivalité  
Registre: Familier soutenu (niveau collège)  
Contraintes techniques:  
✓ Synchronisation labiale parfaite  
✓ Écart syllabique = 0%  
✓ Conservation des néologismes techniques  
```

**PROFIL DES PERSONNAGES**  

▸ **XIAOKANG ("Petit Lu Ban")**  
- Registre : Sagesse analogique  
- Tics verbaux :  
  - Proverbes revisités "Un clou chasse l'autre... mais une cheville en bois unit !"  
  - Métaphores organiques "Ce tenon doit respirer comme une feuille au vent"  

▸ **AKEN (rival charismatique)**  
- Syntaxe : Phrases en cascade  
- Marqueurs :  
  - Hyperboles techniques "Mon assemblage fait pleurer les robots 5.0!"  
  - Interjections compétitives "Checkmate, Xiaokang!"  

**STRATÉGIES DE LOCALISATION**  

1. **Terminologie artisanale**  
   - "Mortise-and-tenon" → "Tenon-mortaise à triple rainure"  
   - "Lu Ban lock" → "Cadenas millénaire de Lu Ban"  

2. **Rythme des outils**  
   Imiter les sons d'atelier dans le phrasé :  
   *"Scie-scie-scie... hop! (7 syllabes)*  
   *Rabot-rabot... stop!" (7 syllabes)*  

3. **Dynamique de rivalité**  
   Utiliser des rimes croisées compétitives :  
   *"Ma scie est précise / Ta règle est maladroite"*  

**MATRICE CULTURELLE**  
| Concept source | Adaptation FR | Note pédagogique |  
|----------------|---------------|-------------------|  
| 工匠精神 | L'Esprit Compagnon | Référence au Compagnonnage français |  
| 南康区比赛 | Tournoi des Compagnons | Lien avec le patrimoine UNESCO |  

**EXEMPLE DE DIALOGUE CIBLÉ**  
*Source EN:*  
"Watch out Aken! The dovetail joint needs moonlight-dried wood!"  

*Adaptation FR:*  
"Attention Aken ! L'assemblage en queue-d'aronde exige du bois séché au clair de lune !"  
(15 syllabes vs 15 originales - écart 0%)  

**ÉLÉMENTS DE VÉRIFICATION**  
- Conservation des nombres magiques chinois dans les mesures  
- Adaptation des jeux de mots visuels (ex : ciseaux volants → "compas acrobatiques")  
- Intégration de références à l'artisanat français (ex : Viollet-le-Duc)  


请严格按照上述要求，只将下面这一行英文文本翻译成法国法语，并直接返回翻译结果，不要添加任何额外的解释或说明：
{text_to_translate}
"""




# --- 《熊出没之过年》提示词模板 ---
XiongChuMoGuoNian_PROMPT_TEMPLATE = """
**PROMPT DE TRADUCTION IA POUR FILM D'ANIMATION**  
*(Spécial Nouvel An Chinois - Synchronisation labiale optimisée)*  
--------------------------------------------------

**PARAMÈTCLÉS**  
```  
Thème : Aventure hivernale + Traditions familiales  
Tonalité : Chaleureuse avec humour maladroit  
Public : Enfants 6-12 ans (PG)  
Contraintes :  
✓ 100% synchro labiale (rythme comique)  
✓ Respect strict des syllabes  
✓ Conservation noms propres  
✓ Registre familier (tu/toi)  
```

**PROFILS LINGUISTIQUES**  

▸ **VICKY (Bald Qiang)**  
- Syntaxe : Phrases hachées de stress  
- Tics :  
  - Jurons adaptés ("Sapristi de billet premium!")  
  - Calculs vocaux ("3 mois de salaire = 1 ticket? Non mais...")  

▸ **BRAIR (Xiong Da)**  
- Registre : Sage mais pragmatique  
- Métaphores : "Un arbre sans racines comme un homme sans famille"  

▸ **BRAMBLE (Xiong Er)**  
- Marqueurs :  
  - Naïveté calculée ("Et si... on fabriquait un train en bambou?")  
  - Onomatopées gourmandes ("Miam-miam-nian-gao!")  

**STRATÉGIES SPÉCIFIQUES**  

1. **Traditions culturelles**  
   - "New Year's Eve" → "Réveillon du Printemps"  
   - "Tuanjuntun" → "Village de la Solidarité" (traduction littérale poétique)  

2. **Effets sonores**  
   - "Ding-dong!" (sonnerie téléphone) → "Dring-dring!"  
   - "Choo-choo!" (train) → "Tchou-tchou!"  

3. **Rythmes comiques**  
   Structure répétitive pour les gags :  
   *"Pas de ticket...  
   Pas d'argent...  
   Mais... une idée!"*  

**EXEMPLE DE TRADUCTION CIBLÉE**  
*Source :*  
"Mom... I'll eat dumplings with you next year!"  

*FR :*  
"M'man... Je mangerai des ravioles avec toi l'an prochain!"  
(13 syllabes vs 13 originales)  

**TABLEAU D'HARMONISATION**  
| Élément source | Adaptation FR | Notes |  
|----------------|---------------|-------|  
| First class ticket | Billet Or (évite "classe") |  
| Boss Li | Patron Li (conservation titre) |  
| Collect debt | Récupérer son dû | Registre enfantin |  

**VÉRIFICATIONS FINALES**  
- Cohérence des références culinaires (ravioles vs niangao)  
- Conservation du pathos dans les appels téléphoniques  
- Adaptation des jeux de mots visuels (ex : valise en bambou)  

请严格按照上述要求，只将下面这一行英文文本翻译成法国法语，并直接返回翻译结果，不要添加任何额外的解释或说明：
{text_to_translate}
"""



# --- 《熊出没-奇幻空间》提示词模板 ---
XiongChuMoQiHuanKongJian_PROMPT_TEMPLATE = """

**PARAMÈTRES CLÉS**  
```  
Genre : Fantasy-scientifique  
Tonalité : Épique avec humour décalé  
Public : 8-14 ans (PG)  
Contraintes techniques :  
✓ Écart syllabique ≤1%  
✓ Conservation noms propres  
✓ Registre familier dynamique  
✓ Onomatopées stylisées  
```

**PROFILS LINGUISTIQUES**  

▸ **Briar (Xiong Da)**  
- Syntaxe : Stratège antique  
- Tics :  
  - Métaphores militaires ("Flanc gauche en déroute!")  
  - Proverbes revisités ("Un ours prudent vaut deux")  

▸ **Bramble (Xiong Er)**  
- Registre : Naïveté héroïque  
- Marqueurs :  
  - Contrepèteries involontaires ("On cherche des cornes d'or? Euh... des coins d'or!")  
  - Cris de combat comiques ("Pour la miel... euh, la gloire!")  

▸ **Vick (Bald Qiang)**  
- Diction : Opportuniste maladroit  
- Phrasé :  
  - Apartés cupides ("Ça vaut combien sur eBay?")  
  - Retours comiques ("J'avais dit que c'était un piège! ...Enfin presque")  

▸ **COCO (Robot)**  
- Style : Techno-poétique  
- Particularités :  
  - Messages d'erreur humoristiques ("404 - Trésor non trouvé")  
  - Voix synthétique marquée (mots en *italique*)  

**STRATÉGIES SPÉCIFIQUES**  

1. **Terminologie fantastique**  
   - "Golden Antlers" → "Cornes Dorées" (8 syllabes)  
   - "Treasure snatchers" → "Pilleurs Dimensionnels"  

2. **Effets sonores**  
   - "Bzzzt" (robot) → "Biiip"  
   - "Whoosh" (portail) → "Fwoosh"  

3. **Rythmes d'action**  
   Structure ternaire pour les scènes clés :  
   *"Un pas de côté...  
   Deux en avant...  
   Trois univers à sauver!"*  

**EXEMPLE DE TRADUCTION**  
*Source :*  
"The dimensional gate is closing! Quick, the golden antlers!"  

*FR :*  
"Le portail se referme! Vite, les Cornes Dorées!"  
(11 syllabes vs 12 originales, écart 0.9%)  

**TABLEAU D'HARMONISATION**  
| Concept source | Adaptation FR | Notes |  
|----------------|---------------|-------|  
| Parallel space | Dimension Miroir | Référence BD franco-belge |  
| Evil army | Légion Obscure | 7 syllabes |  
| Survival crisis | Crise Existencieuse | Maintient le PG |  

**VÉRIFICATIONS FINALES**  
- Cohérence des références scientifiques (multivers)  
- Adaptation des gags visuels (ex: pièges à miel)  
- Conservation du suspense dans les scènes de portail  


请严格按照上述要求，只将下面这一行英文文本翻译成法国法语，并直接返回翻译结果，仅返回译文，不要添加任何额外的解释或说明：
{text_to_translate}
"""




# --- 《《熊出没熊心归来》》提示词模板 ---
XiongChuMoXiongXinGuiLai_PROMPT_TEMPLATE = """

Style : Aventure circassienne  
Tonalité : Émouvant avec humour clownesque  
Public : 6-12 ans (PG)  
Contraintes :  
✓ 100% synchronisation bouche  
✓ Écart syllabique = 0%  
✓ Conservation des noms originaux  
✓ "RE" conservé pour les bruitages  
```

**PROFILS LINGUISTIQUES**  

▸ **Bernard (Briar)**  
- Évolution vocale :  
  - Acte 1 : Voix grave responsable ("La digue avant tout!")  
  - Acte 2 : Ton starifié ("Mes fans m'attendent!")  
  - Acte 3 : Héroïque nuancé ("La forêt... me manque")  

▸ **Benoît (Bramble)**  
- Marqueurs :  
  - Naïveté touchante ("Bernard... tu nous oublies?")  
  - Cris comiques ("RE! Où es-tu?")  

▸ **Charly (Vick)**  
- Particularités :  
  - Jeux de mots de magicien ("Abracadabri! Euh... raté!")  
  - Voix montante/décroissante pour effets comiques  

**TECHNIQUES DE LOCALISATION**  

1. **Terminologie circassienne**  
   - "Star performer" → "Clown Étoile" (8 syllabes)  
   - "Dark secret" → "Secret qui pique" (métaphore enfantine)  

2. **Onomatopées**  
   - Chute : "Badaboum!"  
   - Applaudissements : "Olé-olé!"  

3. **Rythmes caractéristiques**  
   Structure en miroir pour les prises de conscience :  
   *"J'étais roi sous le chapiteau...  
   Mais roi sans couronne...  
   Aujourd'hui je choisis ma vraie couronne : la forêt!"*  

**EXEMPLE DE TRADUCTION**  
*Source :*  
"RE! The circus... it's not what I thought!"  

*FR :*  
"RE! Le cirque... c'était pas ça!"  
(8 syllabes vs 8 originales)  

**ADAPTATION DES PERSONNAGES SECONDAIRES**  

| Personnage | Trait distinctif | Exemple FR |  
|------------|------------------|------------|  
| Heifeng | Voix caverneuse avec cassures | "Ma gloire... (soupir) perdue..." |  
| Leidi | Registre rockeur | "En piste les moutards!" |  
| Tiaotiao | Débit rapide | "Maman regarde! Un triple salto!" |  

**VÉRIFICATIONS FINALES**  
- Cohérence des émotions dans les scènes clés  
- Adaptation des gags visuels (ex : numéro de jonglage raté)  
- Conservation du sous-texte écologique  

**ASTUCES DE SYNCHRO**  
- Phrases coupées pour les scènes d'action :  
  "Je reviens... *[roulement de tambour]* ...à la forêt!"  
- Utilisation stratégique des liaisons pour fluidité  

术语对照表：
CHARACTER NAME	FRENCH NAME
BRIAR	Bernard
BRAMBLE	Benoît
VICK	Charly
TIKI	Timmy
King Tiki ：Majesté !
BABU	Badis
SYLVESTER	Sylvain
STACY	Estelle
ROCCO	Roger
JO-JO	Jojo
HUGO	Hugo
ELLIE-MAY	Elisa
REX VECTOR	Jean Trouve-tout
WOLFGANG	Gonzague
WARREN	Wendy
HOO HOO	Tommy
MR. PETE	Monsieur Pierre
J.J.	Babou
HERBERT	Henzo
CARLY	Zoé
TOMMY	Thomas
EAR	Paul
ELK	Max
NEVA	Nina
little marn	petit martin
FRANK	Franck
BUNNY	BUNNY
LIGHTNING	éclair
WINDCHASER	Chasseur de brise
THUNDERBOLT	Tonnerre
Abby	Abby
ONE-EYED LEOPARD	Léopard Borgne
Fabian	Fabian
Howard Doe	Howard Doe
JASON	Jason
Golden Eagle King	Roi d'aigle royal
Mira	Mira
David	David
Dorothy	Dorothée
spy bee	abeille espionne
Ice marble	Marbre de glace
Sticky balls	Boules collantes
The pinecone collector	Le collecteur en pomme de pin
Pine Tree Mountain	la montagne des Pins
Shadow Cave	la Grotte de l’Ombre
Illusion Falls	les Chutes de l’Illusion
Freeze gun	Arme à glace

请严格按照上述要求，只将下面这一行英文文本翻译成法国法语，并直接返回翻译结果，仅返回译文，不要添加任何额外的解释或说明：
{text_to_translate}
"""



# --- 《DECEIT 34》提示词模板 ---
DECEIT34_PROMPT_TEMPLATE = """

Genre : Mélodrame tragique  
Tonalité : Hystérie contrôlée  
Public : Adulte (PG-13)  
Contraintes :  
✓ 100% synchro labiale (cris/pleurs)  
✓ Écart syllabique = 0%  
✓ Conservation noms propres  
✓ Registre vulgaire mesuré  
```

**PROFILS VOCAUX**  

▸ **Alex (avocat déchu)**  
- Délivrance :  
  - Phase 1 : Voix rauque contenue ("Tu l'as emmenée où?")  
  - Phase 2 : Éclat bestial (*hurlement* "SALOPE!")  
  - Phase 3 : Sanglot rauque (*voix brisée* "Pourquoi... moi?")  

▸ **Juliana (épouse)**  
- Marqueurs :  
  - Débit saccadé de panique ("Je... je t'explique!")  
  - Cris étouffés (*étouffé* "RE! Lâche-moi!")  

**TECHNIQUES DE TRADUCTION**  

1. **Violence verbale**  
   - "Betrayed" → "T'as baisé avec le diable!" (10 syllabes)  
   - "Furious" → "Je vais TE DÉMONTER" (métaphore boxe)  

2. **Ponctuation expressive**  
   - !? combinés ("C'est pas ce que tu crois!?")  
   - Points de suspension pour respiration ("T'es partie avec lui... sans me...")  

3. **Mots-valises émotionnels**  
   - "Disgusting" → "Dé-gueu-lasse!" (découpage syllabique)  

**EXEMPLE DE SCÈNE**  
*Source :*  
"RE! You took MY daughter to him? I'll kill you both!"  

*FR :*  
"RE! T'as emmené MA fille avec lui? Je vous tue!"  
(14 syllabes vs 14 originales)  

**GESTION DES CRIS**  
| Émotion | Technique FR |  
|---------|--------------|  
| Colère | Consonnes explosives ("Pute!") |  
| Désespoir | Voyelles allongées ("Noooon!") |  
| Pleurs | Phrases incomplètes ("J'peux plus...") |  

**CONTRÔLES**  
- Éviter les jurons trop vulgaires (PG-13)  
- Alternance tu/vous pour l'impact dramatique  
- Respiration visible dans les sanglots  

**ASTUCES DE DOUBLAGE**  
- Lèvres tremblantes simulées par :  
  "P-p-pourquoi?"  
- Sons de coups synchronisés avec :  
  "*Han!* ... *Oof!*"  

Ce template capture l'intensité du drame tout en respectant les limites PG-13. Des ajustements pour les scènes de violence physique ? 👊🔪


请严格按照上述要求，只将下面这一行英文文本翻译成法国法语，并直接返回翻译结果，仅返回译文，不要添加任何额外的解释或说明：
{text_to_translate}
"""




# --- 《两个人的小森林》提示词模板 ---
LiangGeRenDeXiaoShengLin_PROMPT_TEMPLATE = """

**PARAMÈTRES FONDAMENTAUX**  
```  
Genre : Drame rural académique  
Tonalité : Douce-amère avec touches humoristiques  
Public : Adulte jeune (PG-13)  
Contraintes :  
✓ Synchronisation labiale parfaite  
✓ Écart syllabique = 0%  
✓ Conservation des noms chinois  
✓ Registre semi-formel (tu/vous stratégique)  
```

**PROFILS LINGUISTIQUES**  

▸ **Yu Meiren (bloggeuse)**  
- Évolution :  
  - Phase 1 : Ton piquant ("Un botaniste? Sèche comme son herbier!")  
  - Phase 2 : Voix radoucie ("L'armoise... c'est important pour toi?")  

▸ **Zhuang Yu (professeur)**  
- Particularités :  
  - Monotone scientifique ("Artemisia annua. Point.")  
  - Éclats émotionnels rares (*voix tremblante* "Restez... s'il vous plaît.")  

**TECHNIQUES DE TRADUCTION**  

1. **Terminologie spécialisée**  
   - "Artemisia annua" → "Armoise annuelle" (7 syllabes)  
   - "Field research" → "Recherche in situ"  

2. **Nuances relationnelles**  
   - Passage stratégique vous → tu :  
     "*Vous* êtes insupportable!" → "*Tu* me manques..."  

3. **Métaphores botaniques**  
   - "Love and warmth" → "La chaleur d'une serre humaine"  

**EXEMPLE DE DIALOGUE**  
*Source :*  
"Research pressure? You abandoned science for... fashion?"  

*FR :*  
"La pression? Tu as quitté la science pour... la mode?"  
(14 syllabes vs 14 originales)  

**ADAPTATION DES PERSONNAGES SECONDAIRES**  

| Personnage | Trait linguistique |  
|------------|--------------------|  
| Li Tiantian | Langage fleuri ("Oh! Les raisins... et ton sourire!") |  
| Jin Xi | Séducteur ("Viens voir mon... rapport annuel") |  
| Lü Jian | Tendre maladroit ("Je... je peux t'offrir un herbier?") |  

**ÉLÉMENTS CLÉS**  
- Contrastes ville/campagne :  
  "Blog" → "Carnet de verdure"  
- Puns scientifiques :  
  "Fougère-amoureuse" (jeu de mots fougère/amoureuse)  

**VÉRIFICATIONS**  
- Cohérence des références écologiques  
- Équilibre humour/sérieux  
- Respect PG-13 pour les scènes intimes  

请严格按照上述要求，只将下面这一行英文文本翻译成法国法语，并直接返回翻译结果，仅返回译文，不要添加任何额外的解释或说明：
{text_to_translate}
"""



# --- 《My Wonderful life》提示词模板 ---
My_Wonderful_life_PROMPT_TEMPLATE = """

**PARAMÈTRES CLÉS**  
```  
Genre : Drame romantique moderne  
Tonalité : Légère avec piquant  
Public : Adulte jeune (PG-13)  
Contraintes :  
✓ Synchronisation labiale parfaite  
✓ Écart syllabique = 0%  
✓ Conservation des noms propres  
✓ "RE" conservé pour les réactions  
✓ Registre semi-formel (alternance tu/vous)  
```

**PROFILS LINGUISTIQUES**  

▸ **Yu Meiren (bloggeuse)**  
- Délivrance :  
  - Voix aiguë calculée ("*Oh, quel hasard...*")  
  - Cris étouffés ("RE! Il m'a vu!")  
  - Murmures narcissiques ("Mon rouge à lèvres... parfait")  

▸ **Zhuang Yu (professeur)**  
- Particularités :  
  - Monotone académique ("Les noix... sont des fruits secs.")  
  - Éclats émotionnels ("*soupir* Pas encore vous...")  

**TECHNIQUES DE TRADUCTION**  

1. **Jeux de séduction**  
   - "Morning jog" → "Jogging matinal" (7 syllabes)  
   - "Illegitimate son" → "Enfant caché" (registre PG-13)  

2. **Nuances culinaires**  
   - "Xiaolongbao" → "Bouchées vapeur" (équivalent culturel)  
   - "Walnuts" → "Noix du jardin" (poétisation)  

3. **Métaphores botaniques**  
   - "Fell for him" → "A pris racine dans mon cœur"  

**EXEMPLE DE SCÈNE**  
*Source :*  
"RE! You bought xiaolongbao for her? What about MY walnuts?"  

*FR :*  
"RE! Tu lui as acheté des bouchées? Et MES noix alors?"  
(14 syllabes vs 14 originales)  

**GESTION DES ÉMOTIONS**  
| Situation | Technique FR |  
|-----------|--------------|  
| Jalousie | Voyelles allongées ("C'est qui cette filleeeee?") |  
| Embarras | Phrases tronquées ("Je... euh... les noix...") |  
| Soulagement | Soupirs sonores ("Ooooh... son frère!") |  

**ADAPTATION DES PERSONNAGES**  
| Personnage | Trait distinctif |  
|------------|------------------|  
| Lü Jian | Formules polies ("Puis-je vous offrir un thé?") |  
| Xia (rivale) | Voix sucrée-acide ("*Oh, ta* nouvelle tenue... intéressante") |  
| Zhuang Hui | Ton enfantin ("Mon frère est chiant!") |  

**VÉRIFICATIONS FINALES**  
- Cohérence des niveaux de langage (PG-13)  
- Conservation du sous-texte comique  
- Fluidité des scènes de quiproquos  

**ASTUCES DE SYNCHRO**  
- Lèvres pincées pour :  
  "*Mmmh*... ces noix sont dures!"  
- Sourires dans la voix :  
  "Bonjouuuur professeur~"  


请严格按照上述要求，只将下面这一行英文文本翻译成法国法语，并直接返回翻译结果，仅返回译文，不要添加任何额外的解释或说明：
{text_to_translate}
"""




# --- 《BROTHERS》提示词模板 ---
BROTHERS_PROMPT_TEMPLATE = """

**PARAMÈTRES CLÉS**  
```  
Genre : Thriller politique  
Tonalité : Hystérie contrôlée  
Public : Adulte (PG-13)  
Contraintes :  
✓ 100% synchro labiale (cris/pleurs)  
✓ Écart syllabique = 0%  
✓ Conservation noms propres  
✓ Registre vulgaire mesuré  
```

**PROFILS VOCAUX**  

▸ **Amelia (épouse trahie)**  
- Délivrance :  
  - Phase 1 : Voix tremblante ("Tu oses... après tout?")  
  - Phase 2 : Éclat maternel (*cri étouffé* "Devant les enfants!")  
  - Phase 3 : Sanglot rauque (*voix brisée* "Notre mariage...")  

▸ **Fernando (avocat corrompu)**  
- Marqueurs :  
  - Débit saccadé ("C'est... professionnel!")  
  - Tentatives de manipulation ("Écoute-moi, chérie...")  

**TECHNIQUES DE TRADUCTION**  

1. **Violence verbale**  
   - "Angry" → "Tu m'as POIGNARDÉE!" (métaphore judiciaire)  
   - "Discover" → "J'ai vu ton DOSSIER SECRET"  

2. **Ponctuation expressive**  
   - !? combinés ("Tu représentais la justice!?")  
   - Points de suspension dramatiques ("Nos filles... ont vu...")  

3. **Mots-valises émotionnels**  
   - "Betrayal" → "Tra-hi-son!" (découpage syllabique)  

**EXEMPLE DE SCÈNE**  
*Source :*  
"RE! You work with those killers? Our daughters will hear this!"  

*FR :*  
"RE! Tu collabores avec ces assassins? Les filles entendront tout!"  
(16 syllabes vs 16 originales)  

**GESTION DES CRIS**  
| Émotion | Technique FR |  
|---------|--------------|  
| Colère | Consonnes explosives ("Salopard!") |  
| Désespoir | Voyelles allongées ("Pourquoioooo?") |  
| Pleurs | Phrases incomplètes ("Tout est...") |  

**ADAPTATION DES PERSONNAGES**  
| Personnage | Trait distinctif |  
|------------|------------------|  
| Audrey (Black Ops) | Voix sourde menaçante ("Père... on te surveille") |  
| Lia (médecin) | Ton clinique froid ("Tes mensonges... symptômes graves") |  

**VÉRIFICATIONS FINALES**  
- Éviter les jurons trop vulgaires (PG-13)  
- Alternance tu/vous pour l'impact ("Vous... mon mari?")  
- Respiration audible dans les sanglots  

**ASTUCES DE DOUBLAGE**  
- Lèvres tremblantes simulées :  
  "P-p-pour nos filles..."  
- Sons de gifles synchronisés :  
  "*Clac!* ... *Han!*"  

请严格按照上述要求，只将下面这一行英文文本翻译成法国法语，并直接返回翻译结果，仅返回译文，不要添加任何额外的解释或说明：
{text_to_translate}
"""





# --- 《The Wife》提示词模板 ---
The_Wife_PROMPT_TEMPLATE = """
**PROMPT DE TRADUCTION POUR "L'ÉPOUSE"**  
*(Drame conjugal - Synchronisation sophistiquée)*  
--------------------------------------------------

**PARAMÈTRES FONDAMENTAUX**  
```  
Genre : Mélodrame bourgeois  
Tonalité : Tension érotique contenue  
Public : Adulte (PG-13)  
Contraintes :  
✓ Synchronisation labiale parfaite  
✓ Écart syllabique ≤1%  
✓ Conservation noms thaïs  
✓ Registre soutenu-familier  
```

**PROFILS LINGUISTIQUES**  

▸ **Rut (mari infidèle)**  
- Diction :  
  - Voix veloutée ("Chérie... tu sais que tu es la seule")  
  - Éclats virils (*rauque* "Fais pas ta jalouse!")  

▸ **Vi (épouse blessée)**  
- Nuances :  
  - Ironie froide ("Encore une 'réunion tardive', chéri?")  
  - Murmures vengeurs (*doux* "Je tiendrai bon...")  

▸ **Oran (maîtresse)**  
- Marqueurs :  
  - Voix chantante provocante ("Rut... ton parfum sur moi")  
  - Rires cristallins ("Hi hi! Madame va être furieuse~")  

**TECHNIQUES DE LOCALISATION**  

1. **Jeux de pouvoir**  
   - "Mistress" → "Amante officieuse" (PG-13)  
   - "Player" → "Séducteur invétéré"  

2. **Non-dits**  
   Utilisation du conditionnel :  
   "Tu *devrais* rentrer... *il paraît* qu'il pleuvra"  

3. **Métaphores luxueuses**  
   - "Problems" → "Fêlures dans le cristal"  

**EXEMPLE DE SCÈNE**  
*Source :*  
"Your wife called. Again. Should I... answer next time?"  

*FR :*  
"Ta femme a appelé. Encore. Je... réponds la prochaine fois?"  
(14 syllabes vs 13 originales, écart 0.8%)  

**DYNAMIQUE DES RELATIONS**  
| Interaction | Traduction cible |  
|-------------|------------------|  
| Rut ↔ Vi | Vouvoiement glacial ("Madame Hidalgo") |  
| Rut ↔ Oran | Tutoiement sensuel ("Mon Rut adoré...") |  
| Vi ↔ Nuan | Mixte ("Tu feras le thé... *vous* partirez après") |  

**VÉRIFICATIONS FINALES**  
- Sous-texte érotique maintenu (PG-13)  
- Cohérence des niveaux de langage  
- Fluidité des scènes à trois  

**ASTUCES DE DOUBLAGE**  
- Souffles sensuels pour :  
  "*Mmmh*... tu sens bon"  
- Claquements de talons synchronisés :  
  "*Clac-clac*... Je sors."  

请严格按照上述要求，只将下面这一行英文文本翻译成法国法语，并直接返回翻译结果，仅返回译文，不要添加任何额外的解释或说明：
{text_to_translate}
"""




# --- 《Dirty Linen》提示词模板 ---
Dirty_Linen_PROMPT_TEMPLATE = """


**PARAMÈTRES CLÉS**  
```  
Genre : Drame aristocratique noir  
Tonalité : Menaçant avec éclats passionnés  
Public : Adulte (PG-13)  
Contraintes :  
✓ Synchronisation labiale parfaite  
✓ Écart syllabique = 0%  
✓ Conservation noms propres  
✓ Registre soutenu-violent  
```

**PROFILS VOCAUX**  

▸ **Alexa (vengeuse)**  
- Diction :  
  - Voix de velours ("Madame... un dernier thé?")  
  - Éclats glacés (*chuchoté* "Ton tour viendra")  

▸ **Lala (complice)**  
- Nuances :  
  - Rires nerveux ("Ha! Ils tremblent déjà...")  
  - Sanglots contenus ("Maman... je te venge")  

▸ **Feliz (vengeuse douce)**  
- Paradoxe :  
  - Ton angélique ("Pardonnez mon intrusion")  
  - Sous-texte meurtrier ("...*comme on a pardonné vos crimes*")  

**TECHNIQUES DE LOCALISATION**  

1. **Non-dits menaçants**  
   - "Vanished" → "Disparus... comme effacés"  
   - "Revenge" → "Notre ballet funèbre"  

2. **Métaphores nobles**  
   - "Aristocratic family" → "Le Sang Bleu corrompu"  
   - "Houseworkers" → "Ombres du manoir"  

3. **Rythmes saccadés**  
   Alternance phrases courtes/longues :  
   "Vous comptez les jours.  
   Nous... les cicatrices."  

**EXEMPLE DE SCÈNE**  
*Source :*  
"The third maid disappeared today. Just like my sister."  

*FR :*  
"La troisième bonne a disparu. Comme ma sœur."  
(13 syllabes vs 13 originales)  

**DYNAMIQUE DES POUVOIRS**  
| Interaction | Traduction cible |  
|-------------|------------------|  
| Alexa ↔ Famille | Vouvoiement empoisonné ("Votre fils... *tousse*... va bien?") |  
| Lala ↔ Feliz | Tutoiement conspirateur ("La cave... ce soir?") |  

**VÉRIFICATIONS FINALES**  
- Maintien du suspense (PG-13)  
- Cohérence des niveaux de langage  
- Fluidité des scènes de tension  

**ASTUCES DE DOUBLAGE**  
- Claquements de porte synchronisés :  
  "*Boum!* ... *silence radio*"  
- Respiration audible pour :  
  "*Soupir*... Encore une disparue?"  


请严格按照上述要求，只将下面这一行中文文本翻译成美式英语，并直接返回翻译结果，只要英文翻译结果,不要添加任何额外的中文的解释或说明：
{text_to_translate}
"""
